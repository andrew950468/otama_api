#!/bin/sh
autoreconf -fi

